<?php


ShortcodeParser::get('default')->register('groupdocsDotNetAnnotation', array('groupdocsDotNetAnnotation', 'handle_shortcode'));
